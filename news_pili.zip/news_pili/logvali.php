<?php
$pass=$_POST['pass'];
$Id=$_POST['id'];

echo"FOUND";
?>

<?php
require 'config.php';

$statement="select *from Register where Id='$Id' and Password='$pass'";
$result = mysqli_query($conn,$statement);

if(mysqli_num_rows($result)>0)
{
//echo $Id;
    header('location:home.php');
}
else
{
	echo"NOT FOUND";
}
  

mysqli_close($conn);
?>