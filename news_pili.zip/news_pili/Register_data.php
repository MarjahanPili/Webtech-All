<?php
/**
 * Created by PhpStorm.
 * User: mdsae
 * Date: 11-Jun-18
 * Time: 9:37 PM
 */

require 'config.php';
$Name=$_POST['fullname'];
$Email=$_POST['txtemail'];
$Password=$_POST['pass'];

$statement="insert into Register(Name,Password,Email) values ('$Name','$Email','$Password')";

if(mysqli_query($conn,$statement))
{
    header('location:home.php');
}
else
    mysqli_error($conn);

mysqli_close($conn);