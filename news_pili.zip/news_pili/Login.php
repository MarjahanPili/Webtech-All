<!DOCTYPE HTML>

<html>
	<head>
		<title>Login form</title>
	</head>
	
	<body>
		
		<form name ="reg" method ="post"action="logvali.php">
		
			<table>
			  <tr>
				<td colspan="2" align="center"><h2>Login Form</h2></td>
			  </tr>
			 
			  <tr>
				<td>Id :</td><td><input type="text" name="id"></td>
			  </tr>
			   <tr>
				<td>pass : </td><td><input type="text" name="pass"></td>				  
			  </tr>
			 
		
			  <tr>
				  <td align="center"><input type="reset" value="Cancel"></td>
				  <td align="center"><input type="submit" value="Submit"></td>
			  </tr>					
		  </table>
		  
		</form> 
	</body>
</html>