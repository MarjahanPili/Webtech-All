<!DOCTYPE HTML>

<html>
	<head>
		<title>Registration form</title>
	</head>
	
	<body>
		
		<form name ="reg" method ="post"action="Register_data.php">
		
			<table>
			  <tr>
				<td colspan="2" align="center"><h2>Registration Form</h2></td>
			  </tr>
			  <tr>
				<td>Fullname : </td><td><input type="text" name="fullname"></td>				  
			  </tr>
			  <tr>
				<td>Email :</td><td><input type="text" name="txtemail"></td>
			  </tr>
			 
			  <tr>
				<td>Password :</td><td><input type="text" name="pass"></td>
			  </tr>
			  <tr>
				<td>Confirm Password :</td><td><input type="text" name="cpass"></td>
			  </tr>
			  <tr>
				  <td align="center"><input type="reset" value="Cancel"></td>
				  <td align="center"><input type="submit" value="Submit"></td>
			  </tr>					
		  </table>
		  
		</form> 
	</body>
</html>