!DOCTYPE html>
<html>
<head>
	<title>REGISTRATION</title>
</head>
<body>
		<a href="Register.php">REGISTRATION</a>
		
</body>
</html>